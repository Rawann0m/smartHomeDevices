//
//  ClassTaskW2D5App.swift
//  ClassTaskW2D5
//
//  Created by Rawan on 13/09/1446 AH.
//

import SwiftUI

@main
struct ClassTaskW2D5App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
