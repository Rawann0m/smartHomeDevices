//
//  CustomHeader.swift
//  ClassTaskW2D5
//
//  Created by Rawan on 13/09/1446 AH.
//

import SwiftUI

struct CustomHeader: View {
    let title: String
    
    var body: some View {
        headerContent
    }

    @ViewBuilder
    private var headerContent: some View {
        Text(title)
            .font(.largeTitle)
            .bold()
            .padding()
            .frame(maxWidth: .infinity)
            .background(Color.gray.opacity(0.2))
    }
}
