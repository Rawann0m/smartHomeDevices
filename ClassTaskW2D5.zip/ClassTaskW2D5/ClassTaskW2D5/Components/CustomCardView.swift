//
//  CustomCardView.swift
//  ClassTaskW2D5
//
//  Created by Rawan on 13/09/1446 AH.
//

import SwiftUI

struct CustomCardView: View {
    let title: String
    let imageName: String
    
    var body: some View {
        //how the cards looks like
        VStack {
            Image(systemName: imageName)
                .resizable()
                .scaledToFit()
                .frame(height: 100)
                .padding()
                .background(Color.purple.opacity(0.5))
                .clipShape(RoundedRectangle(cornerRadius: 10))
            
            Text(title)
                .font(.headline)
                .padding(.top, 5)
        }
        .padding()
    }
}

