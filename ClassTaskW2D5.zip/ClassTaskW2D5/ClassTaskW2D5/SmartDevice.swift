//
//  SmartDevice.swift
//  ClassTaskW2D5
//
//  Created by Rawan on 13/09/1446 AH.
//

import SwiftUI
// device model
struct SmartDevice: Identifiable, Equatable {
    let id = UUID()
    let name: String
    let imageName: String
}
