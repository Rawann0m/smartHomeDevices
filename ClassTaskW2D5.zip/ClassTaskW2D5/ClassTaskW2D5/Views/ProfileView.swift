//
//  ProfileView.swift
//  ClassTaskW2D5
//
//  Created by Rawan on 13/09/1446 AH.
//
import SwiftUI

struct ProfileView: View {
    var animation: Namespace.ID
    @Binding var favoriteDevices: [SmartDevice]
    
    let allDevices = [
        SmartDevice(name: "Smart Light", imageName: "lightbulb"),
        SmartDevice(name: "Smart Speaker", imageName: "speaker"),
        SmartDevice(name: "Smart TV", imageName: "tv"),
        SmartDevice(name: "Smart Thermostat", imageName: "thermometer"),
        SmartDevice(name: "Smart Lock", imageName: "lock.fill")
    ]
    
    var body: some View {
        VStack {
            CustomHeader(title: "Devices")
            
            ScrollView {
                LazyVGrid(columns: [GridItem(.adaptive(minimum: 120))], spacing: 16) {
                    ForEach(allDevices) { device in
                        CustomCardView(title: device.name, imageName: device.imageName)
                            .onTapGesture {
                                toggleFavorite(device)
                            }
                            .overlay(
                                favoriteDevices.contains(device) ?
                                    Image(systemName: "star.fill")
                                        .foregroundColor(.yellow)
                                        .padding(5)
                                        .background(Color.black.opacity(0.7))
                                        .clipShape(Circle())
                                        .offset(x: 40, y: -40)
                                    : nil
                            )
                    }
                }
                .padding()
            }
        }
    }
    
    private func toggleFavorite(_ device: SmartDevice) {
        if favoriteDevices.contains(device) {
            favoriteDevices.removeAll { $0 == device }
        } else {
            favoriteDevices.append(device)
        }
    }
}
