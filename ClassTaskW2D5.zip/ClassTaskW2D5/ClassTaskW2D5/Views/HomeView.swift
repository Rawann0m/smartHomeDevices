//
//  HomeView.swift
//  ClassTaskW2D5
//
//  Created by Rawan on 13/09/1446 AH.
//

import SwiftUI

struct HomeView: View {
    var animation: Namespace.ID
    @Binding var favoriteDevices: [SmartDevice]
    @State private var selectedDevice: SmartDevice?
    var body: some View {
        GeometryReader { geometry in
            VStack {
                CustomHeader(title: "Home")
                
                if favoriteDevices.isEmpty {
                    Text("No favorite devices yet. Add some from the Devices tab!")
                        .padding()
                } else {
                    ScrollView {
                        LazyVGrid(columns: [GridItem(.adaptive(minimum: 120))], spacing: 16) {
                            ForEach(favoriteDevices) { device in
                                CustomCardView(title: device.name, imageName: device.imageName)
                                    .matchedGeometryEffect(id: "device_\(device.id)", in: animation)
                            }
                        }
                        .padding()
                    }
                }
            }
        }
    }
}
