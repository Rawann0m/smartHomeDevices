//
//  ContentView.swift
//  ClassTaskW2D5
//
//  Created by Rawan on 13/09/1446 AH.
//

import SwiftUI

struct ContentView: View {
    @Namespace private var animation
    @State private var selectedTab: Int = 0
    @State private var favoriteDevices: [SmartDevice] = []
    
    var body: some View {
        
        TabView {
            HomeView(animation: animation, favoriteDevices: $favoriteDevices)
                .tabItem {
                    Label("Home", systemImage: "house")
                }
            ProfileView(animation: animation, favoriteDevices: $favoriteDevices)
                .tabItem {
                    Label("Devices", systemImage: "gear")
                }
            
            SettingView()
                .tabItem {
                    Label("Settings", systemImage: "gear")
                }
        }
    }
    
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
}
